# MovieShelf

A React and Vite movie browser powered by The Movie Database (TMDB). It includes popular movies, movie search, favorites saved in local storage, loading indicators, and error messages.

## Setup

1. Get a TMDB API Key from https://www.themoviedb.org/settings/api.
2. Copy `.env.example` to `.env`.
3. Put your TMDB API Key in `.env` as `VITE_TMDB_API_KEY=your_key`.
4. Install dependencies and run the app:

```bash
npm install
npm run dev
```

Do not commit your `.env` file. The API key is needed in the local development environment.
