const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const BASE_URL = import.meta.env.VITE_TMDB_BASE_URL || "https://api.themoviedb.org/3";

async function request(endpoint) {
  if (!API_KEY) {
    throw new Error("TMDB API key is missing. Add VITE_TMDB_API_KEY to your .env file, then restart the app.");
  }

  const separator = endpoint.includes("?") ? "&" : "?";
  const response = await fetch(`${BASE_URL}${endpoint}${separator}api_key=${encodeURIComponent(API_KEY)}`);

  if (!response.ok) {
    if (response.status === 401) {
      throw new Error("TMDB rejected the API key. Check your key in the .env file.");
    }
    throw new Error(`Could not load movies (HTTP ${response.status}). Please try again.`);
  }

  return response.json();
}

export async function getPopularMovies() {
  const data = await request("/movie/popular");
  return data.results || [];
}

export async function searchMovies(query) {
  if (!query.trim()) return [];
  const data = await request(`/search/movie?query=${encodeURIComponent(query.trim())}`);
  return data.results || [];
}
