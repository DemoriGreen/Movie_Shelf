const STORAGE_KEY = "movieshelf-favorites";

export function getFavorites() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveFavorites(movies) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(movies));
}

export function isFavorite(movieId) {
  return getFavorites().some((movie) => movie.id === movieId);
}

export function toggleFavorite(movie) {
  const favorites = getFavorites();
  const exists = favorites.some((item) => item.id === movie.id);
  const updated = exists
    ? favorites.filter((item) => item.id !== movie.id)
    : [...favorites, movie];
  saveFavorites(updated);
  return updated;
}
