import { useState } from "react";
import { Route, Routes, useNavigate } from "react-router-dom";
import Header from "./components/Header.jsx";
import Home from "./pages/Home.jsx";
import Favorites from "./pages/Favorites.jsx";
import { searchMovies } from "./services/movieService.js";

export default function App() {
  const [searchResults, setSearchResults] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState("");
  const navigate = useNavigate();

  async function handleSearch(query) {
    setSearchQuery(query);
    setSearchError("");
    if (!query) {
      setSearchResults([]);
      setIsSearching(false);
      navigate("/");
      return;
    }

    setIsSearching(true);
    navigate("/");
    try {
      const results = await searchMovies(query);
      setSearchResults(results);
    } catch (error) {
      setSearchResults([]);
      setSearchError(error.message || "Search failed. Please try again.");
    } finally {
      setIsSearching(false);
    }
  }

  return (
    <div className="app-shell">
      <Header onSearch={handleSearch} />
      {searchError && <div className="global-error" role="alert">{searchError}</div>}
      <Routes>
        <Route path="/" element={<Home searchResults={searchResults} searchQuery={searchQuery} isSearching={isSearching} />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="*" element={<main className="page-content"><h1>Page not found</h1><p>That page does not exist.</p></main>} />
      </Routes>
      <footer className="site-footer"><span>MovieShelf</span><span>Discover something worth watching.</span><span>Movie data provided by TMDB</span></footer>
    </div>
  );
}
