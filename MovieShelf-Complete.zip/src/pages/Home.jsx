import { useCallback, useEffect, useState } from "react";
import MovieGrid from "../components/MovieGrid.jsx";
import LoadingSpinner from "../components/LoadingSpinner.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { getPopularMovies } from "../services/movieService.js";

export default function Home({ searchResults, searchQuery, isSearching }) {
  const [popularMovies, setPopularMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadPopular = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const movies = await getPopularMovies();
      setPopularMovies(movies);
    } catch (err) {
      setError(err.message || "Could not load popular movies.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPopular();
  }, [loadPopular]);

  const searching = Boolean(searchQuery);
  const movies = searching ? searchResults : popularMovies;

  return (
    <main className="page-content">
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">{searching ? "YOUR NEXT FAVORITE" : "YOUR MOVIE NIGHT STARTS HERE"}</span>
          <h1>{searching ? <>Search <span>results</span></> : <>Find your next<br /><span>favorite movie.</span></>}</h1>
          <p>{searching ? `Showing results for “${searchQuery}”.` : "Explore popular movies, find hidden gems, and keep the ones you love close."}</p>
        </div>
        <div className="hero-art" aria-hidden="true"><span className="art-circle circle-one" /><span className="art-circle circle-two" /><span className="art-ticket">▶</span><span className="art-star">✦</span></div>
      </section>

      <section className="movies-section">
        <div className="section-heading">
          <div><span className="eyebrow">{searching ? "MOVIES MATCHING YOUR SEARCH" : "HANDPICKED FOR YOU"}</span><h2>{searching ? "Search Results" : "Popular Movies"}</h2></div>
          {!searching && !loading && <span className="result-count">{popularMovies.length} movies</span>}
        </div>
        {loading && !searching && <LoadingSpinner />}
        {error && !searching && <ErrorMessage message={error} onRetry={loadPopular} />}
        {isSearching && <LoadingSpinner />}
        {!loading && !error && !isSearching && <MovieGrid movies={movies} />}
      </section>
    </main>
  );
}
