import { useEffect, useState } from "react";
import MovieGrid from "../components/MovieGrid.jsx";
import { getFavorites } from "../utils/favorites.js";

export default function Favorites() {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    setFavorites(getFavorites());
  }, []);

  return (
    <main className="page-content favorites-page">
      <section className="page-title-block">
        <span className="eyebrow">YOUR PERSONAL COLLECTION</span>
        <h1>My <span>Favorites</span></h1>
        <p>All the movies you saved in one place.</p>
      </section>
      <MovieGrid movies={favorites} onFavoriteChange={setFavorites} />
    </main>
  );
}
