import { useState } from "react";
import { isFavorite, toggleFavorite } from "../utils/favorites.js";

const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

export default function MovieCard({ movie, onFavoriteChange }) {
  const [favorite, setFavorite] = useState(() => isFavorite(movie.id));
  const poster = movie.poster_path ? `${IMAGE_BASE}${movie.poster_path}` : "";

  function handleFavorite() {
    const updated = toggleFavorite(movie);
    const nextValue = updated.some((item) => item.id === movie.id);
    setFavorite(nextValue);
    onFavoriteChange?.(updated);
  }

  return (
    <article className="movie-card">
      <div className="poster-wrap">
        {poster
          ? <img className="movie-poster" src={poster} alt={`${movie.title} poster`} loading="lazy" />
          : <div className="poster-placeholder">No poster available</div>}
        <button
          className={`favorite-button ${favorite ? "is-favorite" : ""}`}
          onClick={handleFavorite}
          aria-label={favorite ? `Remove ${movie.title} from favorites` : `Add ${movie.title} to favorites`}
          title={favorite ? "Remove from favorites" : "Add to favorites"}
        >
          {favorite ? "♥" : "♡"}
        </button>
      </div>
      <div className="movie-info">
        <h3>{movie.title || "Untitled"}</h3>
        <div className="movie-meta">
          <span className="rating">★ {Number(movie.vote_average || 0).toFixed(1)}</span>
          <span>{movie.release_date ? movie.release_date.slice(0, 4) : "Release date unknown"}</span>
        </div>
        {movie.overview && <p className="movie-overview">{movie.overview}</p>}
      </div>
    </article>
  );
}
