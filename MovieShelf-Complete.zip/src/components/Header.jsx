import { useState } from "react";
import { Link, NavLink } from "react-router-dom";

export default function Header({ onSearch }) {
  const [query, setQuery] = useState("");

  function submitSearch(event) {
    event.preventDefault();
    onSearch(query.trim());
  }

  function clearSearch() {
    setQuery("");
    onSearch("");
  }

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="brand" onClick={clearSearch}>
          <span className="brand-icon">M</span>
          <span>Movie<span className="brand-accent">Shelf</span></span>
        </Link>
        <form className="search-form" onSubmit={submitSearch}>
          <span className="search-icon" aria-hidden="true">⌕</span>
          <input
            aria-label="Search movies"
            placeholder="Search movies..."
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          {query && <button type="button" className="clear-search" aria-label="Clear search" onClick={clearSearch}>×</button>}
          <button type="submit" className="search-button">Search</button>
        </form>
        <nav className="navigation">
          <NavLink to="/" end onClick={clearSearch}>Discover</NavLink>
          <NavLink to="/favorites">My Favorites</NavLink>
        </nav>
      </div>
    </header>
  );
}
