export default function LoadingSpinner() {
  return (
    <div className="loading-state" role="status" aria-live="polite">
      <span className="spinner" />
      <span>Loading movies...</span>
    </div>
  );
}
