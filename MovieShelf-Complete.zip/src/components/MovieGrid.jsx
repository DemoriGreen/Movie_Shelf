import MovieCard from "./MovieCard.jsx";

export default function MovieGrid({ movies, onFavoriteChange }) {
  if (!movies?.length) {
    return <div className="empty-state"><span className="empty-icon">◌</span><h3>No movies found</h3><p>Try another search or check back later.</p></div>;
  }

  return (
    <div className="movie-grid">
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} onFavoriteChange={onFavoriteChange} />
      ))}
    </div>
  );
}
